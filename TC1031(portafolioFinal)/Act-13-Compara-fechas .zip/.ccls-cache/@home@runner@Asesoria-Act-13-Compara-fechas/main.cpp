/** 
Lizbeth Islas Becerril A01749904
Sebastian Antonio Almanza A01749694
* Ejemplo que implementa objetos de la clase Registro
* que contienen una fecha-hora convertida a Linux timestamp
* para realizar comparaciones (sobrecarga de operadores)
*
* Compilacion para debug:  
*    g++ -std=c++17 -g -o main *.cpp 
* Ejecucion con valgrind:
*    nix-env -iA nixpkgs.valgrind
*    valgrind --leak-check=full ./main
*
* Compilacion para ejecucion:  
*    g++ -std=c++17 -O3 -o main *.cpp 
* Ejecucion:
*    ./main
**/
#include <iostream>
#include "Bitacora.h"

using std::cout;
using std::cin;
using std::endl;

int main() {
  
  Bitacora bitacora;
  bitacora.leerArchivo("bitacora.txt"); 
  //bitacora.print(); 
  bitacora.callMergeSort();
  //bitacora.callbubbleSort();
  bitacora.Busqueda();
  return 0;
}