#ifndef _BITACORA_H_
#define _BITACORA_H_
//Lizbeth Islas Becerril A01749904
//Sebastian Antonio Almanza A01749694

#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#include "Registro.h"

using std::string;
using std::vector;
using std::cout;
using std::endl;
using std::cin;
using std::getline;

class Bitacora {
  private:
    std::vector<Registro> listaRegistros;
    void merge(int low, int m, int high, unsigned int &compara);

  public:
    // TO-DO
    void leerArchivo(std::string filePath);
    int numElements;
    

    // ordenamiento
    void mergeSort(int low, int high, unsigned int &compara);
    void bubbleSort(int n,  unsigned int &compara, unsigned int &swap);
    // busqueda
    int busquedaBinaria(Registro key, unsigned int &compara);

    // print
    void print();
    void callMergeSort();
    void callbubbleSort();
    void callBusquedaBinaria();  

    void Busqueda();
};


#endif  // _BITACORA_H_
