#include "InformacionIp.h"
#include <iostream>

InformacionIp::InformacionIp(){}

InformacionIp::InformacionIp(int _rep, std::string _ipStr, unsigned int _ipDec){
  repeticiones = _rep;
  ipStr = _ipStr;
  ipDecimal = _ipDec;
}


std::ostream& operator<<(std::ostream& os, const InformacionIp& objIp) {
    os << objIp.ipStr + " " + std::to_string(objIp.repeticiones);
    return os;
}

// sobrecarga de operadores de comparacion
bool InformacionIp::operator ==(const InformacionIp &other) const {
  return this->ipDecimal == other.ipDecimal;
}

bool InformacionIp::operator !=(const InformacionIp &other) const {
  return this->ipDecimal != other.ipDecimal;
}

bool InformacionIp::operator  >(const InformacionIp &other) const {
  return this->ipDecimal > other.ipDecimal;
}

bool InformacionIp::operator  <(const InformacionIp &other) const{
  return this->ipDecimal < other.ipDecimal;
}

bool InformacionIp::operator >=(const InformacionIp &other) const{
  return this->ipDecimal >= other.ipDecimal;
}

bool InformacionIp::operator <=(const InformacionIp &other) const{
  return this->ipDecimal <= other.ipDecimal;
}