#ifndef _INFORMACIONIP_H_
#define _INFORMACIONIP_H_

#include <string>
#include <iostream>

class InformacionIp{
  private:
    int repeticiones;
    std::string ipStr;
    unsigned int ipDecimal;

  public:
    InformacionIp();
    InformacionIp(int rep, std::string _ipStr, unsigned int _ipDec);

    // sobrecarga de operadores de comparacion
    bool operator ==(const InformacionIp &other) const;
    bool operator !=(const InformacionIp &other) const;
    bool operator  >(const InformacionIp &other) const;
    bool operator  <(const InformacionIp &other) const;
    bool operator >=(const InformacionIp &other) const;
    bool operator <=(const InformacionIp &other) const;
    friend std::ostream& operator<<(std::ostream& os, const InformacionIp &other);
};






#endif