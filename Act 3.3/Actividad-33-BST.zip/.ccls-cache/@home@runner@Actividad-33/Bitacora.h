#ifndef _BITACORA_H_
#define _BITACORA_H_
//Lizbeth Islas Becerril A01749904
//Sebastian Antonio Almanza A01749694

#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>
#include <sstream>
#include <random>
#include <algorithm>
#include <chrono>
#include "Registro.h"
#include "AlgorithmSort.h"
#include "InformacionIp.h"
#include "MaxHeap.h"


using std::string;
using std::vector;
using std::cout;
using std::endl;
using std::cin;
using std::getline;

class Bitacora {
  private:
    std::vector<Registro> listaRegistros;
    void merge(int low, int m, int high, unsigned int &compara);

    unsigned seed;
    std::mt19937_64 gen;

    MaxHeap<InformacionIp> maxheap;


  public:
    Bitacora();
    // TO-DO
    void leerArchivo(std::string filePath);

    // print
    void print();

    void callHeapSort();

    void Busqueda();

    void recurrenciasIp();
};


#endif  // _BITACORA_H_
