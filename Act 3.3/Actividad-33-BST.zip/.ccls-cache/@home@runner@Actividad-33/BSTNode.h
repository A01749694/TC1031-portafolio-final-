#ifndef _BSTNODE_H_
#define _BSTNODE_H_

template <class T>
class BSTNode {
  public:
    T data;
    BSTNode<T> *left;
    BSTNode<T> *right;

    BSTNode();
    BSTNode(T value);

};
 // Complejidad: O(1)
template <class T>
BSTNode<T>::BSTNode() : data{}, left{nullptr}, right{nullptr} {}

// Complejidad: O(1)
template <class T>
BSTNode<T>::BSTNode(T value) : data{value}, left{nullptr}, right{nullptr} {}


#endif // _BSTNODE_H_
