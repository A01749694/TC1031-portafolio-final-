/*
 * Algoritmos de ordenamiento parte 03
 *
 * Compilación con debug:
 *  g++ -std=c++17 *.cpp -Wall -g -o main
 *
 * Compilación para ejecucion:
 *  g++ -std=c++17 *.cpp -Wall -O3 -o main
 *
 * Ejecución con redireccion (input and output):
 *  ./main < TestCases/t1.txt
 *  ./main < TestCases/t2.txt > salida.txt
 */
//Sebastian Antonio Almanza
//Lizbeth Islas Becerril

#include <iostream>
#include "Bitacora.h"


int main() {
  Bitacora miBitacora;
  //Complejidad O(n)
  miBitacora.leerArchivo("bitacoraHeap.txt");
  miBitacora.callHeapSort();
  //miBitacora.print();
  miBitacora.recurrenciasIp();


  return 0;
  
}