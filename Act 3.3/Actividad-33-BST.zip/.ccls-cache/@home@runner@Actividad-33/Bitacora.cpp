#include "Bitacora.h"
#include "AlgorithmSort.h"
#include <fstream>
//Lizbeth Islas Becerril A01749904
//Sebastian Antonio Almanza A01749694
Bitacora::Bitacora(){
}

//Complejidad O(n)
void Bitacora::leerArchivo(std::string filePath) {
  string mes, dia, horas, minutos, segundos, ip, puerto, falla;
  std::ifstream inputFile(filePath);
  if (!inputFile.good()) {
    inputFile.close();
    throw std::invalid_argument("File not found");    
  }
  else {
    while (!inputFile.eof()) {
      std::getline(inputFile, mes, ' ');
      if (mes.length() > 0) {
        std::getline(inputFile, dia, ' ');
        std::getline(inputFile, horas, ':');
        std::getline(inputFile, minutos, ':');
        std::getline(inputFile, segundos, ' ');
        std::getline(inputFile, ip, ':');
        std::getline(inputFile, puerto, ' ');
        std::getline(inputFile, falla);
        Registro tmpReg(mes, dia, horas, minutos, segundos, ip, puerto, falla);
        listaRegistros.push_back(tmpReg);
      }
    }   
  }
  inputFile.close();
}

//Complejidad O(n)
void Bitacora::print() {
  for (int i = 0; i < (int)listaRegistros.size(); i++) 
    std::cout << listaRegistros[i] << std::endl;
}

//Complejidad O(n log n)
void Bitacora::callHeapSort(){
  int n = listaRegistros.size();
  unsigned int swaps;
  unsigned int comparaciones;
  AlgorithmSort<Registro> ordenar;
  ordenar.callHeap(listaRegistros, n, comparaciones, swaps);
}

//Complejidad O(n log n)
void Bitacora::recurrenciasIp(){
  maxheap.setCapacity((int)listaRegistros.size());
  
  int repeticiones = 0;
  for (int i = 0; i < (int)listaRegistros.size()-1; i++) {
    if (listaRegistros[i] == listaRegistros[i+1]) {
        repeticiones++;
    }
    else {
      InformacionIp tmpInfoIp(repeticiones, listaRegistros[i].getIpStr(), listaRegistros[i].getIpDecimal());
      maxheap.push(tmpInfoIp);
      repeticiones = 0;
    }
  }
  std::cout << std::endl << "top 5" << std::endl;
  for(int i = 0; i < 5; i++){
    InformacionIp tmpIp = maxheap.getTop();
    maxheap.pop();
    std::cout << tmpIp << std::endl;
  }

  for(int i = 0; i < (int)listaRegistros.size(); i++){
    std::ofstream archivo("ips_con_mayor_acceso.txt");
    if(archivo.is_open()){
      while(!maxheap.isEmpty()){
        InformacionIp tempIp = maxheap.getTop();
        maxheap.pop();
        archivo << tempIp << std::endl;
      }
      archivo.close();
    }
  }
  
}
/*
void Bitacora::Busqueda(){
  string fecha1, fecha2;
  string mes, dia, hora, min, segundo;
  string mes_f, dia_f, hora_f, min_f, segundo_f;

  cout << "Ingrese la fecha de inicio en formato (mes, dia, hh:mm:ss)" << endl;
  std::getline(cin, fecha1);
  std::istringstream ss(fecha1);
  ss >> mes;
  ss >> dia;
  std::getline(ss >> std::ws,hora, ':');
  std::getline(ss >> std::ws,min, ':');
  std::getline(ss >> std::ws,segundo, ' ');
  Registro key(mes, dia, hora, min, segundo, "", "", "");

  cout << "Ingrese la fecha de fin en formato (mes, dia, hh:mm:ss)" << endl;
  std::getline(cin, fecha2);
  std::istringstream ss2(fecha2);
  ss2 >> mes_f;
  ss2 >> dia_f;
  std::getline(ss2 >> std::ws,hora_f, ':');
  std::getline(ss2 >> std::ws,min_f, ':');
  std::getline(ss2 >> std::ws,segundo_f, ' ');
  Registro key2(mes_f, dia_f, hora_f, min_f, segundo_f, "", "", "");

  unsigned int comparaciones = 0;
  int pos1 = busquedaBinaria(key, comparaciones);
  int pos2 = busquedaBinaria(key2, comparaciones);

  if(pos1 < 0 && pos2 < 0){
    cout << "No se encontro la fecha" << endl;
  }
  else {
    cout << "Resultados de la busqueda: " << endl;
    for(int i = pos1; i < pos2; i++){
      cout << listaRegistros[i].getAll() << endl;
    }
  }
} 

*/