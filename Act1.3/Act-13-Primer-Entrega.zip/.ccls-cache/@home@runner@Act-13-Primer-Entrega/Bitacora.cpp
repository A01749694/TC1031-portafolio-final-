#include "Bitacora.h"
//Lizbeth Islas Becerril A01749904
//Sebastian Antonio Almanza A01749694
Bitacora::Bitacora(){
  seed = std::chrono::system_clock::now().time_since_epoch().count();
  // generador de numeros aleatorios (Mersenne Twister 64 bits)
  std::mt19937_64 gen;
  // inicializar el generador con la semilla creada
  gen.seed(seed);
}

void Bitacora::randomShuffle(){
  std::shuffle(listaRegistros.begin(),listaRegistros.end(),gen);
}


void Bitacora::leerArchivo(std::string filePath) {
  // TO-DO 
  // Leer cada renglon de bitacora.txt y crear objeto Registro
  // Registro(std::string _mes, std::string _dia, std::string _horas, std::string _minutos, std::string _segundos, std::string _ip, std::string _puerto, std::string _falla)
  // hacer push_back en vector listaRegistros del objeto Registro creado
  string mes, dia, horas, minutos, segundos, ip, puerto, falla;
  std::ifstream inputFile(filePath);
  if (!inputFile.good()) {
    inputFile.close();
    throw std::invalid_argument("File not found");    
  }
  else {
    while (!inputFile.eof()) {
      std::getline(inputFile, mes, ' ');
      if (mes.length() > 0) {
        std::getline(inputFile, dia, ' ');
        std::getline(inputFile, horas, ':');
        std::getline(inputFile, minutos, ':');
        std::getline(inputFile, segundos, ' ');
        std::getline(inputFile, ip, ':');
        std::getline(inputFile, puerto, ' ');
        std::getline(inputFile, falla);
        Registro tmpReg(mes, dia, horas, minutos, segundos, ip, puerto, falla);
        listaRegistros.push_back(tmpReg);
      }
    }   
  }
  inputFile.close();
}

void Bitacora::merge(int low, int m, int high, unsigned int &compara){
  int i, j, k;
  // Calcular el tamaño de los vectores L y R
  int n1 = m - low + 1;
  int n2 = high - m;
  // Crear los vectores auxiliares L y R
  std::vector<Registro> L(n1);
  std::vector<Registro> R(n2);
  for (i = 0; i < n1; i++) L[i] = listaRegistros[low + i];
  for (j = 0; j < n2; j++) R[j] = listaRegistros[m + 1 + j];
  // Mezclar los vectores L y R de forma ordenada
  i = j = 0;
  k = low;
  while (i < n1 && j < n2) {
    compara++;
    if (L[i] <= R[j]) {
      listaRegistros[k] = L[i];
      i++;
    }
    else {
      listaRegistros[k] = R[j];
      j++;
    }
    k++;
  }
  // Copia los elementos restantes de L y R
  while (i < n1) {
    listaRegistros[k] = L[i];
    i++;
    k++;
  }
  while (j < n2) {
    listaRegistros[k] = R[j];
    j++;
    k++;
  }
}
//Complejidad O(n log n)
void Bitacora::mergeSort(int low, int high, unsigned int &compara){
  if(low < high){
    int m = low + (high - low)/2;
    mergeSort(low, m, compara);
    mergeSort(m+1, high, compara);
    merge(low, m, high, compara);
  }
}

void Bitacora::print() {
  for (int i = 0; i < (int)listaRegistros.size(); i++) 
    std::cout << listaRegistros[i].getAll() << std::endl;
}

void Bitacora::callMergeSort() {
  unsigned int comparaciones = 0;
  mergeSort(0, listaRegistros.size()-1, comparaciones);
  cout << "Num de comparaciones de mergeSort: " << comparaciones << endl;
}

void Bitacora::callbubbleSort(){
  unsigned int comparaciones = 0;
  unsigned int swap = 0;
  
  bubbleSort(comparaciones, swap);
  cout << "Num de comparaciones de bubbleSort: " << comparaciones << endl;
  cout << "Num de swaps de bubbleSort: " << swap << endl;
}

//complejidad : O(log2 n)
int Bitacora::busquedaBinaria(Registro key, unsigned int &compara){
  int l = 0;
  int r = listaRegistros.size() - 1;
  compara = 0;
  while (l <= r) {
    int m = l + (r - l) / 2;
    compara++;
    if (key == listaRegistros[m])
      return m;
    else if (key < listaRegistros[m]) 
      r = m - 1;
    else
      l = m + 1;
  }
  return -1;
}

//complejidad: O(n^2)
void Bitacora::bubbleSort(unsigned int &compara, unsigned int &swap){
  int n = listaRegistros.size();
  compara = swap = 0;
  for (int i = 0; i < n-1; i++) {
    for (int j = 0; j < n-i-1; j++) {
      compara++;
      if (listaRegistros[j] > listaRegistros[j+1]) {
        std::swap(listaRegistros[j], listaRegistros[j+1]);
        swap++;
      }
    }
  }
}

void Bitacora::Busqueda(){
  string fecha1, fecha2;
  string mes, dia, hora, min, segundo;
  string mes_f, dia_f, hora_f, min_f, segundo_f;
  
  cout << "Ingrese la fecha de inicio en formato (mes, dia, hh:mm:ss)" << endl;
  std::getline(cin, fecha1);
  std::istringstream ss(fecha1);
  ss >> mes;
  ss >> dia;
  std::getline(ss >> std::ws,hora, ':');
  std::getline(ss >> std::ws,min, ':');
  std::getline(ss >> std::ws,segundo, ' ');
  Registro key(mes, dia, hora, min, segundo, "", "", "");

  cout << "Ingrese la fecha de fin en formato (mes, dia, hh:mm:ss)" << endl;
  std::getline(cin, fecha2);
  std::istringstream ss2(fecha2);
  ss2 >> mes_f;
  ss2 >> dia_f;
  std::getline(ss2 >> std::ws,hora_f, ':');
  std::getline(ss2 >> std::ws,min_f, ':');
  std::getline(ss2 >> std::ws,segundo_f, ' ');
  Registro key2(mes_f, dia_f, hora_f, min_f, segundo_f, "", "", "");

  unsigned int comparaciones = 0;
  int pos1 = busquedaBinaria(key, comparaciones);
  int pos2 = busquedaBinaria(key2, comparaciones);

  if(pos1 < 0 && pos2 < 0){
    cout << "No se encontro la fecha" << endl;
  }
  else {
    cout << "Resultados de la busqueda: " << endl;
    for(int i = pos1; i < pos2; i++){
      cout << listaRegistros[i].getAll() << endl;
    }
  }
} 

