#ifndef _BITACORA_H_
#define _BITACORA_H_
//Lizbeth Islas Becerril A01749904
//Sebastian Antonio Almanza A01749694

#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>
#include <sstream>
#include <random>
#include <algorithm>
#include <chrono>
#include "Registro.h"

using std::string;
using std::vector;
using std::cout;
using std::endl;
using std::cin;
using std::getline;

class Bitacora {
  private:
    std::vector<Registro> listaRegistros;
    void merge(int low, int m, int high, unsigned int &compara);

    unsigned seed;
    std::mt19937_64 gen;
    

  public:
    Bitacora();
    // TO-DO
    void leerArchivo(std::string filePath);
    

    // ordenamiento
    void mergeSort(int low, int high, unsigned int &compara);
    void bubbleSort(unsigned int &compara, unsigned int &swap);
    // busqueda
    int busquedaBinaria(Registro key, unsigned int &compara);

    // print
    void print();
    void callMergeSort();
    void callbubbleSort();
    void callBusquedaBinaria();  

    void Busqueda();
    void randomShuffle();
};


#endif  // _BITACORA_H_
