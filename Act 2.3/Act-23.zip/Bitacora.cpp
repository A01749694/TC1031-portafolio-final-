#include "Bitacora.h"
//Lizbeth Islas Becerril A01749904
//Sebastian Antonio Almanza A01749694

//Complejidad O(n)
void Bitacora::leerArchivo(std::string filePath) {
  // hacer push_back en vector listaRegistros del objeto Registro creado
  string mes, dia, horas, minutos, segundos, ip, puerto, falla;
  std::ifstream inputFile(filePath);
  if (!inputFile.good()) {
    inputFile.close();
    throw std::invalid_argument("File not found");    
  }
  else {
    while (!inputFile.eof()) {
      std::getline(inputFile, mes, ' ');
      if (mes.length() > 0) {
        std::getline(inputFile, dia, ' ');
        std::getline(inputFile, horas, ':');
        std::getline(inputFile, minutos, ':');
        std::getline(inputFile, segundos, ' ');
        std::getline(inputFile, ip, ':');
        std::getline(inputFile, puerto, ' ');
        std::getline(inputFile, falla);
        Registro tmpReg(mes, dia, horas, minutos, segundos, ip, puerto, falla);
        listaRegistros.addLast(tmpReg);
      }
    }   
  }
  inputFile.close();
}

// Complejidad O(n)
void Bitacora::print() {
  listaRegistros.printList();  // usa operador << sobrecargado
}

//Complejiodad O(n log n)
void Bitacora::callQuickSort(){
  listaRegistros.callQuickSort();
}

//Complejidad O(n log n)
void Bitacora::callMergeSort(){
  listaRegistros.callMerge();
}


//Complejidad O(log n)
void Bitacora::Busqueda(){
  string fecha1, fecha2;
  string mes, dia, hora, min, segundo;
  string mes_f, dia_f, hora_f, min_f, segundo_f;

  cout << "Ingrese la fecha de inicio en formato (mes, dia, hh:mm:ss)" << endl;
  std::getline(cin, fecha1);
  std::istringstream ss(fecha1);
  ss >> mes;
  ss >> dia;
  std::getline(ss >> std::ws,hora, ':');
  std::getline(ss >> std::ws,min, ':');
  std::getline(ss >> std::ws,segundo, ' ');
  Registro key(mes, dia, hora, min, segundo, "", "", "");

  cout << "Ingrese la fecha de fin en formato (mes, dia, hh:mm:ss)" << endl;
  std::getline(cin, fecha2);
  std::istringstream ss2(fecha2);
  ss2 >> mes_f;
  ss2 >> dia_f;
  std::getline(ss2 >> std::ws,hora_f, ':');
  std::getline(ss2 >> std::ws,min_f, ':');
  std::getline(ss2 >> std::ws,segundo_f, ' ');
  Registro key2(mes_f, dia_f, hora_f, min_f, segundo_f, "", "", "");

  posInicial = listaRegistros.callBinarySearch(key);
  posFinal = listaRegistros.callBinarySearch(key2);

  if(posInicial != nullptr && posFinal != nullptr){
    DLLNode<Registro> *p = posInicial;
    while(p != nullptr || p != posFinal -> next){
      std::cout << p->data.getAll() << std::endl;
      p = p -> next;
    }
    std::cout << std::endl;
  }
 
} 

