#ifndef _BITACORA_H_
#define _BITACORA_H_
//Lizbeth Islas Becerril A01749904
//Sebastian Antonio Almanza A01749694

#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>
#include <sstream>
#include <random>
#include <algorithm>
#include <chrono>
#include "Registro.h"
#include "DLLinkedList.h"

using std::string;
using std::vector;
using std::cout;
using std::endl;
using std::cin;
using std::getline;

class Bitacora {
  private:
    DLinkedList<Registro> listaRegistros; 
    DLLNode<Registro>*  posInicial;
    DLLNode<Registro>*  posFinal;
  public:
    void leerArchivo(std::string filePath);

    //Ordenamiento
    void callQuickSort();
    // print
    void print();
    void callMergeSort();
    void Busqueda();
};


#endif  // _BITACORA_H_
