//Lizbeth Islas Becerril
//Sebas Antonio Almanza
#ifndef _DOUBLELINKEDLIST_H_
#define _DOUBLELINKEDLIST_H_

#include <iostream>
#include <stdexcept>
#include "DLLNode.h"

template <class T>
class DLinkedList {
  private:
    DLLNode<T> *head;
    DLLNode<T> *tail;
    int numElements;
    DLLNode<T>* partition(DLLNode<T> *l, DLLNode<T> *h);
    void quickSort(DLLNode<T> *head);  
    void _quickSort(DLLNode<T>* l, DLLNode<T> *h); 
    DLLNode<T> *middle(DLLNode<T> *start, DLLNode<T> *last);
    DLLNode<T> *binarySearch(DLLNode<T> *head, T value);
    DLLNode<T> *merge(DLLNode<T>*first, DLLNode<T>*second);
    DLLNode<T> *mergeSort(DLLNode<T>* head);
    DLLNode<T> *split(DLLNode<T>* head);

  public:
    DLinkedList();
    ~DLinkedList();
    int getNumElements();
    void printList();
    void printReverseList();
    void addFirst(T value);
    void addLast(T value);
    DLLNode<T> *getHead();
    bool deleteData(T value);
    bool deleteAt(int position);
    T getData(int position);
    void updateData(T value, T newValue);
    void updateAt(int position, T newValue);
    void invert();
    //void getRevertedSublist(int start, int end);
    //DLinkedList<T>* getReversedSublist(int ini, int fin);
    void callQuickSort();
    DLLNode<T>* callBinarySearch(T value);
    void callMerge();

};

// Complejidad O(1)
template <class T>
DLinkedList<T>::DLinkedList() {
  //std::cout << "--> Creando una lista ligada vacia: " << this << std::endl; 
  head = nullptr;
  tail = nullptr;
  numElements = 0;
}

// Complejidad O(n)
template <class T>
DLinkedList<T>::~DLinkedList() {
  //std::cout << "--> Liberando memoria de la lista ligada: " << this << std::endl;
  DLLNode<T> *p, *q;
  p = head;
  while (p != nullptr) {
    q = p->next;
    delete p;
    p = q;
  }
  head = nullptr;
  tail = nullptr;
  numElements = 0;
}

//Complejidad O(1)
template <class T>
DLLNode<T> *DLinkedList<T>::getHead() {
  return head;
} 

// Complejidad O(1)
template <class T>
int DLinkedList<T>::getNumElements() {
  return numElements;  
}

// Complejidad O(n)
template <class T>
void DLinkedList<T>::printList() {
  if (head == nullptr && tail == nullptr)
    std::cout << "La lista esta vacia" << std::endl;
  else {
    std::cout << "El contenido de la lista es: " << std::endl;
    DLLNode<T> *p = head;
    while(p != nullptr) {
      std::cout << p->data << " ";
      p = p->next;
    }
    std::cout << std::endl;
  }    
}

// Complejidad O(n)
template <class T>
void DLinkedList<T>::printReverseList() {
  if (head == nullptr && tail == nullptr)
    std::cout << "La lista esta vacia" << std::endl;
  else {
    std::cout << "El contenido inverso de la lista es: " << std::endl;
    DLLNode<T> *p = tail;
    while(p != nullptr) {
      std::cout << p->data << " ";
      p = p->prev;
    }
    std::cout << std::endl;
  }    
}

// Complejidad O(1)
template <class T>
void DLinkedList<T>::addFirst(T value) {
  // 1. crear nuevo nodo
  DLLNode<T> *newNode = new DLLNode<T>(value);
  // si la lista esta vacia
  if (head == nullptr && tail == nullptr) {
    head = newNode;
    tail = newNode;
  }
  else {
    // 2. apuntar newNode->next al nodo apuntado por head
    newNode->next = head;
    // 3. apuntar head->prev a newNode
    head->prev = newNode;
    // 4. actualizar head para apuntar a newNode
    head = newNode;
  }
  numElements++;
}

// Complejidad O(1)
template <class T>
void DLinkedList<T>::addLast(T value) {
  // La lista esta vacia
  if (head == nullptr && tail == nullptr)
    addFirst(value);
  else {
      // 1. crear nuevo nodo
      DLLNode<T> *newNode = new DLLNode<T>(value);
      // 2. apuntar tail->next a newNode
      tail->next = newNode;
      // 3. apuntar newNode->prev a tail
      newNode->prev = tail;
      // 3. actualizar tail para apuntar a newNode
      tail = newNode;
      numElements++;
  }
}

// Complejidad O(n)
template <class T>
bool DLinkedList<T>::deleteData(T value) {
  // La lista esta vacia
  if (head == nullptr && tail == nullptr) {
    std::cout << "La lista esta vacia" << std::endl;
    return false;
  }
  else {
    // Buscar value en la lista
    DLLNode<T> *p = head;
    DLLNode<T> *previous = nullptr;
    while(p != nullptr && p->data != value) {
      previous = p;
      p = p->next;
    }
    // si value no esta en la lista
    if (p == nullptr) {
      std::cout << "El valor no existe en la lista" << std::endl;
      return false;
    }
    // si debo borrar el primer nodo de la lista
    if (p != nullptr && p == head) {
      head = p->next;
      if (head == nullptr) // habia solo un nodo en la lista
        tail = nullptr;
      else
        head->prev = nullptr;
    }
    else if (p->next == nullptr) { // borrar el ultimo nodo
      previous->next = nullptr;
      tail = previous;
    }
    else { // borrar cualquier otro nodo
      previous->next = p->next;
      p->next->prev = previous;
    }
    // borrar el nodo apuntado por p
    delete p;
    p = nullptr;
    numElements--;
    return true;
  }
}

// Complejidad O(n)
template <class T>
bool DLinkedList<T>::deleteAt(int position) {
  // Validar position
  if (position < 0 || position >= numElements) {
    throw std::out_of_range("Indice fuera de rango");
  } 
  else if (position == 0) { // primer nodo 
    DLLNode<T> *p = head;
    // si la lista contiene un solo nodo
    if (p != nullptr && p->next == nullptr) {
      head = nullptr;
      tail = nullptr;
    }
    else {
      head = p->next;
      head->prev = nullptr;
    }
    delete p;
    p = nullptr;
    numElements--;
    return true;
  }
  else {
    // Buscar position en la lista
    DLLNode<T> *p = head;
    DLLNode<T> *previous = nullptr;
    int index = 0;
    while(index != position) {
      previous = p;
      p = p->next;
      index++;
    }
    // debo borrar el ultimo nodo
    if (p->next == nullptr) {
      previous->next = nullptr;
      tail = previous;
    }
    else { // borrar cualquier otro nodo
      previous->next = p->next;
      p->next->prev = previous;
    }
    delete p;
    p = nullptr;
    numElements--;
    return true;    
  }
}

// Complejidad O(n)
template <class T>
T DLinkedList<T>::getData(int position) {
  // Validar position
  if (position < 0 || position >= numElements) {
    throw std::out_of_range("Indice fuera de rango");
  } 
  else if (position == 0) { // primer nodo 
    return head->data;
  }
  else { // si es cualquier otra posicion
    // Buscar position en la lista
    DLLNode<T> *p = head;
    int index = 0;
    while(index != position) {
      p = p->next;
      index++;
    }
    if (p != nullptr)
      return p->data;
    else
      return {};
  }
}

// Complejidad O(n)
template <class T>
void DLinkedList<T>::updateData(T value, T newValue) {
  // Buscar value en la lista
  DLLNode<T> *p = head;
  while(p != nullptr && p->data != value) {
    p = p->next;
  }
  if (p != nullptr)
    p->data = newValue;
  else
    throw std::out_of_range("El elemento a actualizar no existe en la lista");
}


// Complejidad O(n)
template <class T>
void DLinkedList<T>::updateAt(int position, T newValue) {
  // Validar position
  if (position < 0 || position >= numElements) {
    throw std::out_of_range("Indice fuera de rango");
  }
  else {
    // Buscar position en la lista
    DLLNode<T> *p = head;
    int index = 0;
    while(index != position) {
      p = p->next;
      index++;
    }
    if (p != nullptr)
      p->data = newValue;
  }
}
 // Fragmentos de codigo extraidos de Geeks for Geeks 
//Liga https://www.geeksforgeeks.org/cpp-program-for-quicksort-on-doubly-linked-list/
//Liga Binary search: https://www.geeksforgeeks.org/binary-search-on-singly-linked-list/
//Liga merge sort: https://www.geeksforgeeks.org/merge-sort-for-linked-list/

//Complejidad O(n)
template <class T>
DLLNode<T>* DLinkedList<T>::partition(DLLNode<T> *l, DLLNode<T> *h)  
{  
    // set pivot as h element  
    T x = h->data;  

    // similar to i = l-1 for array implementation  
    DLLNode<T> *i = l->prev;  

    // Similar to "for (int j = l; j <= h- 1; j++)"  
    for (DLLNode<T> *j = l; j != h; j = j->next)  
    {  
        if (j->data <= x)  
        {  
            // Similar to i++ for array  
            i = (i == nullptr)? l : i->next;  

            std::swap(i->data, j->data);  
        }  
    }  
    i = (i == nullptr)? l : i->next; // Similar to i++  
    std::swap(i->data, h->data);
    return i;  
}  

//Complejidad O(n log n)
template<class T>
void DLinkedList<T>::_quickSort(DLLNode<T>* l, DLLNode<T> *h)  
{  
    if (h != nullptr && l != h && l != h->next)  
    {  
        DLLNode<T> *p = partition(l, h);  
        _quickSort(l, p->prev);  
        _quickSort(p->next, h);  
    }  
}  

//Complejidad O(n log n)
template<class T>
void DLinkedList<T>::callQuickSort(){
  std::cout << "Ordenar por QuickSort" << std::endl;
  _quickSort(head, tail);
}

//Complejidad O(n)
template<class T>
void DLinkedList<T>::invert(){
  DLLNode<T> *p = head;
  DLLNode<T> *temp = nullptr;

  while(p != nullptr){
    temp = p -> prev;
    p -> prev = p -> next;
    p -> next = temp;

    p = p -> prev;
  }
  temp = head;
  head = tail;
  tail = temp;
}

//Complejidad O(n)
template<class T>
DLLNode<T>* DLinkedList<T>::middle(DLLNode<T> *start, DLLNode<T> *last){
  if(start == nullptr){
    return nullptr;
  }
  DLLNode<T> *slow = start;
  DLLNode<T> *fast = start -> next;
  while(fast != last){
    fast = fast -> next;
    if(fast != last){
      slow = slow -> next;
      fast = fast -> next;
    }
  }
  return slow;
}

//Complejidad O(log n)
template<class T>
DLLNode<T>* DLinkedList<T>::binarySearch(DLLNode<T> *head, T value){
  DLLNode<T> *start = head;
  DLLNode<T> *last = nullptr;

  do{
    DLLNode<T> *mid = middle(start,last);
    if(mid == nullptr){
      return nullptr;
    }
    if(mid->data == value) {
      return mid;
    }
    else if(mid->data < value){
      start = mid->next;
    } 
    else {
      last = mid;
    }
  } while(last == nullptr || last != start);
  return nullptr;
}

//complejidad O(n)
template <class T>
DLLNode<T>* DLinkedList<T>::merge(DLLNode<T>*first, DLLNode<T>*second) { 
    // If first linked list is empty 
    if (!first) 
        return second; 
    // If second linked list is empty 
    if (!second) 
        return first; 
    // Pick the smaller value 
    if (first->data < second->data)  { 
        first->next = merge(first->next,second); 
        first->next->prev = first; 
        first->prev = NULL; 
        return first; 
    } 
    else { 
        second->next = merge(first,second->next); 
        second->next->prev = second; 
        second->prev = NULL; 
        return second; 
    } 
} 

//Complejiad O(n)
template <class T>
DLLNode<T>* DLinkedList<T>::split(DLLNode<T>* head) { 
  DLLNode<T>* fast = head, *slow = head; 
    while (fast->next && fast->next->next) { 
        fast = fast->next->next; 
        slow = slow->next; 
    } 
    DLLNode<T>* temp = slow->next; 
    slow->next = NULL; 
    return temp; 
} 

//Complejidad O(n log n)
template <class T>
DLLNode<T>* DLinkedList<T>::mergeSort(DLLNode<T>* head) { 
    if (!head || !head->next) 
        return head; 
    DLLNode<T>*second = split(head); 
    // Recur for left and right halves 
    head = mergeSort(head); 
    second = mergeSort(second); 

    // Merge the two sorted halves 
    return merge(head,second);
} 

//Complejidad O(n log n)
template<class T>
void DLinkedList<T>::callMerge(){
  head = mergeSort(head);
  DLLNode<T> *p, *q;
  p = head;
  q = nullptr;
  while (p != nullptr) {
    q = p->next;
    p = q;
  }
  tail = q;
}

//Complejidad O(n log n)
template<class T>
DLLNode<T>* DLinkedList<T>::callBinarySearch(T value){
  DLLNode<T> *p = head;
  return binarySearch(p, value);
}

/*
//Complejidad O(n)
template<class T>
DLinkedList<T>* DLinkedList<T>::getReversedSublist(int ini, int fin) {
  DLinkedList<int>* sublist = new DLinkedList<T>();
  //validar ini y fin en rango
  if(ini > 0 && ini < fin && fin < numElements){
    DLLNode<T> *p = head;
    int index = 0;
    while(p != nullptr && index <= fin) {
      if (index >= ini) 
        sublist->addFirst(p->data);
      p = p->next;
      index++;
    }
  }
  return sublist;
}
*/

#endif  // _DOUBLELINKEDLIST_H_