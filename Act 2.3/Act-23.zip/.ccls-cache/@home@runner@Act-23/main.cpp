/**
 * Ejemplo que implementa una lista doblemente ligada con head y tail
 *
 * Compilacion para debug:
 *    g++ -std=c++17 -Wall -g -o main *.cpp
 * Ejecucion con valgrind:
 *    nix-env -iA nixpkgs.valgrind
 *    valgrind --leak-check=full ./main
 *    https://www.youtube.com/watch?v=8JEEYwdrexc 
 *
 * Compilacion para ejecucion:
 *    g++ -std=c++17 -Wall -O3 -o main *.cpp
 * Ejecucion:
 *    ./main
 **/
//Sebastian Antonio Almanza A01749694
//Lizbeth Islas Becerril A01749694
#include <iostream>
#include "Bitacora.h"

using std::cout;
using std::cin;
using std::endl;

int main() {
  Bitacora bitacora;
  try{
    bitacora.leerArchivo("bitacora.txt"); 
  } catch (const std::invalid_argument& error) {
    std::cerr << "Error: " << error.what() << endl;
    return 1;
  }
  bitacora.callMergeSort();
  //bitacora.callQuickSort();
  bitacora.Busqueda();
  
  return 0;
}